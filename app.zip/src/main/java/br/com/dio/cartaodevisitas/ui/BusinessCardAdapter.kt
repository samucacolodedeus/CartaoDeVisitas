package br.com.dio.cartaodevisitas.ui

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import br.com.dio.cartaodevisitas.data.BussinesCard
import br.com.dio.cartaodevisitas.databinding.ItemCartaoVisitaBinding

class BusinessCardAdapter :
    ListAdapter<BussinesCard, BusinessCardAdapter.ViewHolder>(DiffCallback()){

        var listenerShare: (View) -> Unit = {}

       inner class ViewHolder(
           private val binding: ItemCartaoVisitaBinding
       ) : RecyclerView.ViewHolder(binding.root){
           fun bind(item: BussinesCard){
               binding.txtName.text = item.nome
               binding.txtTelefone.text = item.telefone
               binding.txtEmail.text = item.email
               binding.txtEmpresa.text = item.empresa
               binding.card.setCardBackgroundColor(Color.parseColor(item.fundoPersonalizado))
               binding.card.setOnClickListener{
                   listenerShare(it)
               }
           }
       }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemCartaoVisitaBinding.inflate(inflater, parent, false)

        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
}

class DiffCallback: DiffUtil.ItemCallback<BussinesCard>(){
    override fun areItemsTheSame(oldItem: BussinesCard, newItem: BussinesCard) = oldItem == newItem
    override fun areContentsTheSame(oldItem: BussinesCard, newItem: BussinesCard) =
        oldItem.id == newItem.id
}