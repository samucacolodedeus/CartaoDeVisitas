package br.com.dio.cartaodevisitas.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import br.com.dio.cartaodevisitas.App
import br.com.dio.cartaodevisitas.R
import br.com.dio.cartaodevisitas.data.BussinesCard
import br.com.dio.cartaodevisitas.databinding.ActivityAddCartaoDeVisitaBinding

class AddCartaoDeVisita : AppCompatActivity() {

    private val binding by lazy{ ActivityAddCartaoDeVisitaBinding.inflate(layoutInflater)}

    private val mainViewModel: MainViewModel by viewModels {
        MainViewModelFactory((application as App).repository)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        insertListeners()
    }

    private fun insertListeners(){
        binding.btnClose.setOnClickListener {
            finish()
        }
        binding.btnConfirm.setOnClickListener {
            val bussinesCard = BussinesCard(
                nome = binding.titleName.editText?.text.toString(),
                empresa = binding.titleEmpresa.editText?.text.toString(),
                telefone = binding.titleTelefone.editText?.text.toString(),
                email = binding.titleEmail.editText?.text.toString(),
                fundoPersonalizado = binding.titleCor.editText?.text.toString()
            )
            mainViewModel.insert(bussinesCard)
            Toast.makeText(this, R.string.label_show_sucess, Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}