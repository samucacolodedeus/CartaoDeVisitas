package br.com.dio.cartaodevisitas

import android.app.Application
import br.com.dio.cartaodevisitas.data.AppDataBase
import br.com.dio.cartaodevisitas.data.BusinessCardRepository

class App : Application() {
    val database by lazy { AppDataBase.getDatabase(this) }
    val repository by lazy {BusinessCardRepository(database.businessDao())}
}