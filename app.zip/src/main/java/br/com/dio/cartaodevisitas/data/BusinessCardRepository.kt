package br.com.dio.cartaodevisitas.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

class BusinessCardRepository (private val dao: BusinessCardDao){

    fun insert(bussinesCard: BussinesCard) = runBlocking {
        launch(Dispatchers.IO){
            dao.insert(bussinesCard)
        }
    }

    fun getAll() = dao.getAll()
}